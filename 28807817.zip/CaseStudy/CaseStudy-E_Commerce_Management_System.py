import datetime

class Product:
    def __init__(self, product_id, name, description, price, stock_quantity):
        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price
        self.stock_quantity = stock_quantity

class Customer:
    def __init__(self, customer_id, name, email, address):
        self.customer_id = customer_id
        self.name = name
        self.email = email
        self.address = address

class Order:
    def __init__(self, order_id, customer_id, product_id, order_date, quantity):
        self.order_id = order_id
        self.customer_id = customer_id
        self.product_id = product_id
        self.order_date = order_date
        self.quantity = quantity

class ECommerceManagementSystem:
    def __init__(self):
        self.products = {}
        self.customers = {}
        self.orders = {}
        self.next_product_id = 1
        self.next_customer_id = 1
        self.next_order_id = 1

    # Product Management
    def add_product(self):
        name = input("Enter product name: ")
        description = input("Enter product description: ")
        price = float(input("Enter product price: "))
        stock_quantity = int(input("Enter product stock quantity: "))
        product_id = self.next_product_id
        self.products[product_id] = Product(product_id, name, description, price, stock_quantity)
        self.next_product_id += 1
        print(f"Product '{name}' added with ID {product_id}.")

    def update_product(self):
        product_id = int(input("Enter product ID to update: "))
        if product_id in self.products:
            product = self.products[product_id]
            name = input(f"Enter new name (current: {product.name}): ") 
            description = input(f"Enter new description (current: {product.description}): ") 
            price = input(f"Enter new price (current: {product.price}): ")
            stock_quantity = input(f"Enter new stock quantity (current: {product.stock_quantity}): ")
            product.name = name
            product.description = description
            product.price = float(price) if price else product.price
            product.stock_quantity = int(stock_quantity) if stock_quantity else product.stock_quantity
            print(f"Product ID {product_id} updated.")
        else:
            print(f"Product ID {product_id} not found.")

    def delete_product(self):
        product_id = int(input("Enter product ID to delete: "))
        if product_id in self.products:
            del self.products[product_id]
            print(f"Product ID {product_id} deleted.")
        else:
            print(f"Product ID {product_id} not found.")

    # Customer Management
    def add_customer(self):
        name = input("Enter customer name: ")
        email = input("Enter customer email: ")
        address = input("Enter customer address: ")
        customer_id = self.next_customer_id
        self.customers[customer_id] = Customer(customer_id, name, email, address)
        self.next_customer_id += 1
        print(f"Customer '{name}' added with ID {customer_id}.")

    def update_customer(self):
        customer_id = int(input("Enter customer ID to update: "))
        if customer_id in self.customers:
            customer = self.customers[customer_id]
            name = input(f"Enter new name (current: {customer.name}): ") 
            email = input(f"Enter new email (current: {customer.email}): ") 
            address = input(f"Enter new address (current: {customer.address}): ") 
            customer.name = name
            customer.email = email
            customer.address = address
            print(f"Customer ID {customer_id} updated.")
        else:
            print(f"Customer ID {customer_id} not found.")

    def delete_customer(self):
        customer_id = int(input("Enter customer ID to delete: "))
        if customer_id in self.customers:
            del self.customers[customer_id]
            print(f"Customer ID {customer_id} deleted.")
        else:
            print(f"Customer ID {customer_id} not found.")

    # Order Management
    def place_order(self):
        customer_id = int(input("Enter customer ID: "))
        if customer_id not in self.customers:
            print(f"Customer ID {customer_id} not found.")
            return

        product_id = int(input("Enter product ID: "))
        if product_id not in self.products:
            print(f"Product ID {product_id} not found.")
            return

        product = self.products[product_id]
        quantity = int(input(f"Enter quantity (available: {product.stock_quantity}): "))
        
        if product.stock_quantity < quantity:
            print(f"Insufficient stock for product ID {product_id}.")
            return

        order_id = self.next_order_id
        order_date = datetime.date.today()
        self.orders[order_id] = Order(order_id, customer_id, product_id, order_date, quantity)
        product.stock_quantity -= quantity
        total_price = quantity * product.price
        self.next_order_id += 1
        print(f"Order placed with ID {order_id}. Total price: ${total_price:.2f}")

    def update_order(self):
        order_id = int(input("Enter order ID to update: "))
        if order_id not in self.orders:
            print(f"Order ID {order_id} not found.")
            return

        order = self.orders[order_id]
        customer_id = input(f"Enter new customer ID (current: {order.customer_id}): ")
        product_id = input(f"Enter new product ID (current: {order.product_id}): ")
        quantity = input(f"Enter new quantity (current: {order.quantity}): ")

        if customer_id:
            order.customer_id = int(customer_id)
        if product_id:
            new_product_id = int(product_id)
            if order.product_id != new_product_id:
                old_product = self.products[order.product_id]
                old_product.stock_quantity += order.quantity
                if new_product_id not in self.products:
                    print(f"Product ID {new_product_id} not found.")
                    return
                new_product = self.products[new_product_id]
                if new_product.stock_quantity < int(quantity):
                    print(f"Insufficient stock for product ID {new_product_id}.")
                    return
                new_product.stock_quantity -= int(quantity)
                order.product_id = new_product_id
        if quantity:
            new_quantity = int(quantity)
            product = self.products[order.product_id]
            if product.stock_quantity + order.quantity < new_quantity:
                print(f"Insufficient stock for product ID {order.product_id}.")
                return
            product.stock_quantity += order.quantity
            product.stock_quantity -= new_quantity
            order.quantity = new_quantity
            total_price = new_quantity * product.price
        print(f"Order ID {order_id} updated. Total price: ${total_price:.2f}")

    def delete_order(self):
        order_id = int(input("Enter order ID to delete: "))
        if order_id in self.orders:
            order = self.orders[order_id]
            product = self.products[order.product_id]
            product.stock_quantity += order.quantity
            del self.orders[order_id]
            print(f"Order ID {order_id} deleted.")
        else:
            print(f"Order ID {order_id} not found.")

def main():
    system = ECommerceManagementSystem()
    while True:
        print("\nE-commerce Management System")
        print("1. Add Product")
        print("2. Update Product")
        print("3. Delete Product")
        print("4. Add Customer")
        print("5. Update Customer")
        print("6. Delete Customer")
        print("7. Place Order")
        print("8. Update Order")
        print("9. Delete Order")
        print("10. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            system.add_product()
        elif choice == '2':
            system.update_product()
        elif choice == '3':
            system.delete_product()
        elif choice == '4':
            system.add_customer()
        elif choice == '5':
            system.update_customer()
        elif choice == '6':
            system.delete_customer()
        elif choice == '7':
            system.place_order()
        elif choice == '8':
            system.update_order()
        elif choice == '9':
            system.delete_order()
        elif choice == '10':
            break
        else:
            print("Invalid choice, please try again.")

if __name__ == "__main__":
    main()
